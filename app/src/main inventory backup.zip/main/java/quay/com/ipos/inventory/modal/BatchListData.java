package quay.com.ipos.inventory.modal;

import java.util.List;

/**
 * Created by niraj.kumar on 6/22/2018.
 */

public class BatchListData {
    public int tabId;
    public String tabTitle;
    public List<GRNProductDetailModel> modelList;

}
