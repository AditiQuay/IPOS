package quay.com.ipos.ddrsales.model.response;

import java.util.List;

public class DDTProductBatch {
    public int position;
    public int totalQty;
    public int batchQty;
    public String itemName;
    public String itemCode;

    public List<DDRBatch> batchList;

}
