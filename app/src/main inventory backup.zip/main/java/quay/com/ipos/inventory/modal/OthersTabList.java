package quay.com.ipos.inventory.modal;

import android.os.Parcelable;

import java.io.Serializable;

/**
 * Created by niraj.kumar on 6/22/2018.
 */

public class OthersTabList implements Serializable {
    public int tabId;
    public String tabTitle;
}
