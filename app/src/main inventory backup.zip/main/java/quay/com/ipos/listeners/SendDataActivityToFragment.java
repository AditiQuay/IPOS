package quay.com.ipos.listeners;

/**
 * Created by niraj.kumar on 6/25/2018.
 */

public interface SendDataActivityToFragment {
    void sendData(String customerCode,String title,String gender,String customerId,int localId);
}
