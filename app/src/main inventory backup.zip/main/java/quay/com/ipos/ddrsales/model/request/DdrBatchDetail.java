package quay.com.ipos.ddrsales.model.request;

public class DdrBatchDetail {


        public String number;
        public String actionTitle;
        public int actionID;
        public int qty;
}
