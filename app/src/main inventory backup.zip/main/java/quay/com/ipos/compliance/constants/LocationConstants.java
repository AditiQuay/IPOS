package quay.com.ipos.compliance.constants;

/**
 * Created by bijay.laxmi on 03-04-2018.
 */

public class LocationConstants {


        // The minimum time between updates in milliseconds for GPS
        public static final long LOCATION_INTERVAL = 60000; // 0 minute
        public static final int FASTEST_LOCATION_INTERVAL = 50000;
        public static String LOCATION_SEARCH_DATE="";
        public static String LOCATION_START_DATE="";
        public static int SELECTED_VIEW_ID;
        public static final int LOCATION_PIN_FLAG=120;
        public static final Double EARTH_RADIUS = 6371.00;
        public static final int SAME_LOCATION_COUNT_FLAG=2;
        public static final int START_LOCATION_TIME=9;
        public static final int END_LOCATION_TIME=18;
}
