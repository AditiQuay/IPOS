package quay.com.ipos.compliance.constants;

import android.support.annotation.IntDef;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * Created by deepak.kumar1 on 23-03-2018.
 */

public class AnnotationStoreType {
      public static final int ALL = 0;
      public static final int SINGLE = 1;



      @IntDef({ALL, SINGLE})
      @Retention(RetentionPolicy.SOURCE)
      public @interface StoreType{
      }


}

