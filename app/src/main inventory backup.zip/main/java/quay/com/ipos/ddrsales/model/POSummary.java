package quay.com.ipos.ddrsales.model;

import java.util.List;

public class POSummary {
    public List<POSummaryData> data;
}



