package quay.com.ipos.partnerConnect.partnerConnectModel;

/**
 * Created by niraj.kumar on 6/7/2018.
 */

public class BillingModel {
    private String addressType;
    private String billingAddress;
    private String billingCity;
    private String billingState;
    private String billingGSTIN;
    private String billingContactPerson;
    private String billingContactPersonNumber;
    private String billingAddressType;
    private String billingBusinessPlace;

    public String getAddressType() {
        return addressType;
    }

    public void setAddressType(String addressType) {
        this.addressType = addressType;
    }



    public String getBillingAddress() {
        return billingAddress;
    }

    public void setBillingAddress(String billingAddress) {
        this.billingAddress = billingAddress;
    }

    public String getBillingCity() {
        return billingCity;
    }

    public void setBillingCity(String billingCity) {
        this.billingCity = billingCity;
    }

    public String getBillingState() {
        return billingState;
    }

    public void setBillingState(String billingState) {
        this.billingState = billingState;
    }

    public String getBillingGSTIN() {
        return billingGSTIN;
    }

    public void setBillingGSTIN(String billingGSTIN) {
        this.billingGSTIN = billingGSTIN;
    }

    public String getBillingContactPerson() {
        return billingContactPerson;
    }

    public void setBillingContactPerson(String billingContactPerson) {
        this.billingContactPerson = billingContactPerson;
    }

    public String getBillingContactPersonNumber() {
        return billingContactPersonNumber;
    }

    public void setBillingContactPersonNumber(String billingContactPersonNumber) {
        this.billingContactPersonNumber = billingContactPersonNumber;
    }

    public String getBillingAddressType() {
        return billingAddressType;
    }

    public void setBillingAddressType(String billingAddressType) {
        this.billingAddressType = billingAddressType;
    }

    public String getBillingBusinessPlace() {
        return billingBusinessPlace;
    }

    public void setBillingBusinessPlace(String billingBusinessPlace) {
        this.billingBusinessPlace = billingBusinessPlace;
    }
}
