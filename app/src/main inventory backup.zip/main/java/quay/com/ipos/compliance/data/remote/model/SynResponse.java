package quay.com.ipos.compliance.data.remote.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class SynResponse {


    @Expose
    @SerializedName("PrevID")
    public String PrevId;

    @Expose
    @SerializedName("NewId")
    public String NewId;

}
   /* [
    {
        "PrevID": "25",
            "NewId": "24"
    }
]*/




