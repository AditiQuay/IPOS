package quay.com.ipos.kycPartnerConnect;

import com.google.gson.Gson;

import quay.com.ipos.partnerConnect.model.PCModel;

public class KYCAcceptData {
    public String empCode;
    public String jsutification;
    public String requestCode;
    public PCModel pssRespnce;


}
