package quay.com.ipos.listeners;

import android.support.v4.app.FragmentActivity;

/**
 * Created by ankush.bansal on 27-04-2018.
 */

public interface SendScannerBarcodeListener
{
    public void onScanBarcode(String title, FragmentActivity activity);
}