package quay.com.ipos.partnerConnect.model;

public class PssPrincipleContact {
    public String pssContactPersonName;
    public String pssDesignation;
    public String keyEntityEmpMobile1;
    public String keyEntityEmpEmail;


   /* {
        "pssContactPersonName": "Deepak Kumar",
            "pssDesignation": "Programmer",
            "keyEntityEmpMobile1": "9876543210",
            "keyEntityEmpEmail": "deepak.kumar1@quayintech.com"
    }*/
}
