package quay.com.ipos.listeners;

/**
 * Created by niraj.kumar on 5/10/2018.
 */

public interface DataSheetDownloadListener {
    void onDataSheetDownload(int position);
    void onCartBtnClick(int position);
    void onCalculatorSheetDownload(int position);
}
