package quay.com.ipos.listeners;

import android.content.Context;

import quay.com.ipos.modal.ProductListResult;

/**
 * Created by ankush.bansal on 27-04-2018.
 */

public interface ScanFilterListener
{
    public void onUpdate(String title, Context mContext);
}