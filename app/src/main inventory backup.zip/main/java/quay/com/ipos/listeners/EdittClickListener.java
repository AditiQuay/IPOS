package quay.com.ipos.listeners;

/**
 * Created by niraj.kumar on 6/21/2018.
 */

public interface EdittClickListener {
    void updateValue(int position,String value,String title);
}
