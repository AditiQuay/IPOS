package quay.com.ipos.compliance.constants;

/**
 * Created by deepak.kumar1 on 11-05-2018.
 */

public class ReminderType {
    public static final int KEY_TASK = 0;
    public static final int KEY_SUBTASK = 1;
}
