package quay.com.ipos.compliance.constants;

/**
 * Created by Bijay.Laxmi on 3/6/2018.
 */

public class URLStorage {

    public static final String BASE_URL = "http://13.127.101.233:8087/";
    public static final String SUB_BASE_URL = "api/";

    public static final String LOGIN_URL = SUB_BASE_URL+"Token/GenerateToken";
    public static final String FORGOT_PASSWORD_URL = SUB_BASE_URL+"Account/ForgotPassword";
    public static final String RESET_PASSWORD_URL = SUB_BASE_URL+"Account/ResetPassword";
    public static final String USER_PROFILE_URL = SUB_BASE_URL+"ComplianceTracker/GetTaskschedularDetails";
    public static final String USER_PROFILE_URL_NEW = SUB_BASE_URL+"RetailCustomers/GetRetailCustomeBaseAddInfo";
    public static final String USER_PROFILE_URL_NEW2 = SUB_BASE_URL+"PSSConnects";
    public static final String SYNC_DATA_URL = SUB_BASE_URL+"ComplianceTracker/SyncSubTaskschedularData";
    public static final String USER_LOCATION_TRACKER_URL = SUB_BASE_URL+"LocationTracker/InsertEmpLocationDetail";
    public static final String URL_VEHICLE_UPDATE = SUB_BASE_URL+"Profile/UpdateVehicleDetail";
    //report
    public static final String GET_REPORT_URL = SUB_BASE_URL+"UserReport/GetUserReport";
    public static final String GET_REPORT_DROP_DOWN_URL = SUB_BASE_URL+"UserReport/GetUserRequestedCCGLDropdown";


    //dashboard

    public static final String GET_SPEND_REQUEST_DASHBOARD_URL = SUB_BASE_URL+"SpendRequestDashboard/GetSpendRequestDashboard";
    public static final String DASHBOARD_DRILL_DOWN_ONE_URL = SUB_BASE_URL+"SpendRequestDashboard/GetSRDashboardSummary";
    public static final String DASHBOARD_DRILL_DOWN_TWO_URL = SUB_BASE_URL+"SpendRequestDashboard/GetSRDashboardRequestSummary";

    public static final String GET_BALANCE_AMOUNT_URL = SUB_BASE_URL+"SpendRequest/GetBalanceAmount";
    public static final String CREATE_SPEND_REQUEST_URL = SUB_BASE_URL+"SpendRequest/CreateSpendRequest";


    public static final String GET_SPEND_REQUEST_LIST_URL = SUB_BASE_URL+"SpendRequest/GetSpendRequestList";

    public static final String GET_SPEND_REQUEST_HISTORY_LIST_URL = SUB_BASE_URL+"SpendRequest/GetSpendRequestHistory";


    public static final String GET_SPENDREQUEST_VIEW_URL = SUB_BASE_URL+"SpendRequest/GetSpendRequestView";
    public static final String SPEND_REQUEST_APPROVE_URL = SUB_BASE_URL+"SpendRequest/SpendRequestApprove";



}
