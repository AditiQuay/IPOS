package quay.com.ipos.ddrsales.model;

public class LogisticsData {


    public static final String TransportMode[] = {"Partner Vehicle", " Own Vehicle", "Transporter"};

    public String mode="";
    public String lrNumber="";
    public String transporter="";
    public String truckNumber="";
    public String eWayBillNumber="";
    public String eWayBillValidity="";
    public String trackMobileNumber="";
    public String driverName="";
    public String driverMobileNumber="";
    public String address="";


}
