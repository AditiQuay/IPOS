package quay.com.ipos.partnerConnect.model;

public class PssLOBS {
    public String pssType;

    public String pssLobName;

    public String pssLobCode;

    
}
