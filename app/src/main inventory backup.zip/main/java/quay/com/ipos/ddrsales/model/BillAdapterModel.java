package quay.com.ipos.ddrsales.model;

public class BillAdapterModel {
    public String Id;
    public String strTitle;
    public String strBody;

    public BillAdapterModel(String id, String strTitle, String strBody) {
        Id = id;
        this.strTitle = strTitle;
        this.strBody = strBody;
    }
}
