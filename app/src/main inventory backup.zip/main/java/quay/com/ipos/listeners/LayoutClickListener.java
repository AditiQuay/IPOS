package quay.com.ipos.listeners;

/**
 * Created by niraj.kumar on 6/19/2018.
 */

public interface LayoutClickListener {
    void onCardClicked(int position);
}
