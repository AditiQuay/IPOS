package quay.com.ipos.inventory.modal;

/**
 * Created by niraj.kumar on 6/20/2018.
 */

public class GrnInccoTermsModel {
    public String grnIncoDetail;
    public boolean grnPayBySender;
    public boolean grnPayByReceiver;
    public double grnPayAmount;

}
