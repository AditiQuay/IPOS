package quay.com.ipos.ddrsales.model.request;

import java.util.List;

public class DDRPaymentDetail {
    public String paymentType;
    public List<DDRDetailInfo> dDRDetailInfo = null;


}
