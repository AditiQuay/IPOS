package quay.com.ipos.inventory.modal;

/**
 * Created by niraj.kumar on 6/13/2018.
 */

public class InventoryGRNModel {
    public String grnQty;
    public String apQTY;
    public String value;
    public String grnAttachments;
    public String grnWarning;
}
