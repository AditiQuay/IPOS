package quay.com.ipos.data.remote.model;

public class KycPartnerConnectUpdateResponse {
    public int statusCode;
    public int error;
    public String errorDescription;
    public String message;
    public boolean response;

   /* {
        "statusCode": 200,
            "response": true,
            "message": "success"
    }*/

}
