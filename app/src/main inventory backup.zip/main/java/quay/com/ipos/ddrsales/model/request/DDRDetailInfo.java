package quay.com.ipos.ddrsales.model.request;

public class DDRDetailInfo {
    public String cardExpirationDate;
    public String cardLastDigits;
    public double cardPaymentAmt;
    public String cardTxnId;
    public String cardType;
    public boolean cashIsCOD;
    public double cashReceivedAmt;
    public double cashReturnAmt;
    public double totalAmt;
}
