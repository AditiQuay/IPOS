package quay.com.ipos.compliance.constants;


import java.util.ArrayList;

//Key Constants
public class KeyConstants {

    public static final String KEY_ROLE_CCHEAD = "CCHead";
    public static final String KEY_ROLE_RM = "Manager";
    public static final String KEY_ROLE_USER = "User";


    public static final String KEY_USERID = "userId";

    public static  final String KEY_TYPE_BUSINESS = "Business";
    public static  final String KEY_TYPE_STATUTORY = "Stattutory";

    public static  final String KEY_TASK_TYPE_SUBTASK = "task";
    public static  final String KEY_TASK_TYPE_TASK = "subtask";




    public static final ArrayList<String> extensions = new ArrayList<String>();

    public static ArrayList<String> getExtension() {
        extensions.add(".pdf");
        extensions.add(".png");
        extensions.add(".jpeg");
        extensions.add(".jpg");
        //extensions.add(".txt");
        extensions.add(".PDF");
        extensions.add(".PNG");
        extensions.add(".JPEG");
        extensions.add(".JPG");
        //extensions.add(".TXT");
        return extensions;
    }

    public static String[] name = {"Insight & Analytics","Planner","Settle Expenses","Settings"};
    public static String[] subName = {"Daily Allowance", "Travel", "business Expenses","Petty Cash" };
    //Shared preferenceKey
    public static final String ACCESS_TOKEN = "AccessToken";
    public static final String REFRESH_TOKEN = "RefreshToken";
    public static final String TOKEN = "Token";
    public static final String OTP = "Otp";
    public static final String EMAIL = "Email";
    public static final String ISLOGGEDIN = "ISLOGGEDIN";
    public static final String FCMTOKEN = "fcmToken";

    public static Boolean PHASE_FLAG_SR = false;
    public static Boolean PHASE_FLAG_AC = false;
    public static Boolean PHASE_FLAG_SRVF = false;
    public static Boolean PHASE_FLAG_ACVF = false;


    public static String REQUEST_CODE="";
    public static String CURRENT_TAB_AC="In Progress";
    public static boolean CURRENT_TAB_AC_SELECT_INP=false;
    public static boolean CURRENT_TAB_AC_SELECT_MYP=true;
    public static boolean CURRENT_TAB_AC_SELECT_COM=false;
    public static boolean CURRENT_TAB_AC_SELECT_REJ=false;

    public static String CURRENT_TAB_SR="In Progress";
    public static boolean CURRENT_TAB_SR_SELECT_INP=false;
    public static boolean CURRENT_TAB_SR_SELECT_MYP=true;
    public static boolean CURRENT_TAB_SR_SELECT_COM=false;
    public static boolean CURRENT_TAB_SR_SELECT_REJ=false;

    public static boolean SUBMIT_SCREEN_BACK_REFRESH=false;

    public static boolean CURRENT_MENU_FLAG;
    public static boolean CURRENT_MENU_GLOBAL_DASHBOARD_FLAG;

    public static String PHASE_FLAG="Phase_One";
    public static String PHASE_ONE_FLAG="Phase_One";
    public static String PHASE_SEC_FLAG="Phase_Sec";

    public static String CONFIRM_FLAG="Confirm_Flag_Yes";
    public static String CONFIRM_FLAG_YES="Confirm_Flag_Yes";
    public static String CONFIRM_FLAG_NO="Confirm_Flag_No";



}