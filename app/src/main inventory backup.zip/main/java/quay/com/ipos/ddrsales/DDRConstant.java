package quay.com.ipos.ddrsales;

public interface DDRConstant {
    interface OrderSummaryTAB {
        public static final String NEW = "New";
        public static final String ACCEPTED = "Accepted";
        public static final String DISPATCHED = "Dispatched";
        public static final String DELIVERED = "Delivered";
        public static final String CANCELLED = "Cancelled";
    }
}
