package quay.com.ipos.modal;

public class GlobalSettings {
    public String Access ;
    public String IposDB;
    public String PSSDB ;
    public String ServerIP ;

   /*            "GlobalSettings": {
                 "Access": "Both",
                "IposDB": "C001_QuayIPOS",
                "PSSDB": "C001_QuayPSS",
                "ServerIP": "10.0.2.157"
    }*/
}
