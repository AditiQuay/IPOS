package quay.com.ipos.ddrsales.model.response;

public class DDRIncoTerm {
    public int grnIncoId;
    public String grnIncoDetail;
    public boolean grnPayBySender;
    public boolean grnPayByReceiver;
    public double grnPayAmount;
}
