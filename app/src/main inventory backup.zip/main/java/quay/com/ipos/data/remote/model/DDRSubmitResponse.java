package quay.com.ipos.data.remote.model;

public class DDRSubmitResponse {
    public int statusCode;
    public int error;
    public String errorDescription;
    public String message;
    public boolean response;
    public String ddrOrderId;
    public String ddrOrderDate;



   /* {
            "error": 200,
             "errorDescription": "",
               "message": "Order has been created successfully",
             "ddrOrderId": "BB18000011",
             "ddrOrderDate": "5-Jul-2018"
    }*/

}
