package quay.com.ipos.inventory.modal;

/**
 * Created by ankush.bansal on 15-06-2018.
 */

public class POAttachments {

    public String pOAttachmentName;
    public String pOAttachmentUrl;
    public String pOAttachmentType;


    public String getpOAttachmentName() {
        return pOAttachmentName;
    }

    public void setpOAttachmentName(String pOAttachmentName) {
        this.pOAttachmentName = pOAttachmentName;
    }

    public String getpOAttachmentUrl() {
        return pOAttachmentUrl;
    }

    public void setpOAttachmentUrl(String pOAttachmentUrl) {
        this.pOAttachmentUrl = pOAttachmentUrl;
    }

    public String getpOAttachmentType() {
        return pOAttachmentType;
    }

    public void setpOAttachmentType(String pOAttachmentType) {
        this.pOAttachmentType = pOAttachmentType;
    }
}
