package quay.com.ipos.listeners;

/**
 * Created by niraj.kumar on 4/17/2018.
 */

public interface MyListenerOnitemClick {
    void onRowClickedOnItem(int position, int percent,double value);

}
