package quay.com.ipos.ddrsales.model.response;

import java.util.List;

import quay.com.ipos.ddrsales.model.DDR;

public class GetDDRList {
    public List<DDR> dDRList;

}
