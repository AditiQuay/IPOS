package quay.com.ipos.partnerConnect.partnerConnectModel;

/**
 * Created by niraj.kumar on 6/7/2018.
 */

public class BusinessModel {
    public String getPartnerType() {
        return partnerType;
    }

    public void setPartnerType(String partnerType) {
        this.partnerType = partnerType;
    }

    public String getPartnerCompanyName() {
        return partnerCompanyName;
    }

    public void setPartnerCompanyName(String partnerCompanyName) {
        this.partnerCompanyName = partnerCompanyName;
    }

    public String getPartnerCinNumber() {
        return partnerCinNumber;
    }

    public void setPartnerCinNumber(String partnerCinNumber) {
        this.partnerCinNumber = partnerCinNumber;
    }

    public String getPartnerPanNumber() {
        return partnerPanNumber;
    }

    public void setPartnerPanNumber(String partnerPanNumber) {
        this.partnerPanNumber = partnerPanNumber;
    }

    public String getPartnerKeyContact() {
        return partnerKeyContact;
    }

    public void setPartnerKeyContact(String partnerKeyContact) {
        this.partnerKeyContact = partnerKeyContact;
    }

    public String getPartnerContactPosition() {
        return partnerContactPosition;
    }

    public void setPartnerContactPosition(String partnerContactPosition) {
        this.partnerContactPosition = partnerContactPosition;
    }

    private String partnerType;
    private String partnerCompanyName;
    private String partnerCinNumber;
    private String partnerPanNumber;
    private String partnerKeyContact;
    private String partnerContactPosition;

    public String getPartnerState() {
        return partnerState;
    }

    public void setPartnerState(String partnerState) {
        this.partnerState = partnerState;
    }

    public String getPartnerCity() {
        return partnerCity;
    }

    public void setPartnerCity(String partnerCity) {
        this.partnerCity = partnerCity;
    }

    public String getPartnerPinCode() {
        return partnerPinCode;
    }

    public void setPartnerPinCode(String partnerPinCode) {
        this.partnerPinCode = partnerPinCode;
    }

    public String getPartnerZone() {
        return partnerZone;
    }

    public void setPartnerZone(String partnerZone) {
        this.partnerZone = partnerZone;
    }

    private String partnerState;
    private String partnerCity;
    private String partnerPinCode;
    private String partnerZone;
}
