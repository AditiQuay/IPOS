package quay.com.ipos.ddrsales.model.response;

import java.util.List;

public class DDRProductListResponse {
    public List<Address> address;
   /* @SerializedName("listData")*/
  /*  public List<DDRProduct> productList;*/
    public List<DDRIncoTerm> ddrIncoTerms;
}
