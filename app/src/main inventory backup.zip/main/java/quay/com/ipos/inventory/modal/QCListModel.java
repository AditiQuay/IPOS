package quay.com.ipos.inventory.modal;

/**
 * Created by ankush.bansal on 28-06-2018.
 */

public class QCListModel {



}
