package quay.com.ipos.data.remote.model;

public class KCYApproveResponse {
    public String error;
    public String message;
    public String response;
    public String statusCode;
   // public String error;
/*    {"error":0,"message":"success","response":true,"statusCode":200}*/
}
