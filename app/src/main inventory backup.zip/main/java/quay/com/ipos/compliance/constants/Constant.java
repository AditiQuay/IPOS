package quay.com.ipos.compliance.constants;

/**
 * Created by deepak.kumar1 on 29-03-2018.
 */

public interface Constant {

//    public final String BASE_URL = "http://api.randomuser.me/";
    public final String BASE_URL = "http://10.10.1.98:8080/";
    public final String RANDOM_STORE_URL = "http://10.10.1.98:8080/jwtauth/public/configApi/1";
    public final String RANDOM_USER_URL = "http://api.randomuser.me/?results=10&nat=en";
    public final String PROJECT_URL = "https://github.com/AhmadShubita/MVVM-with-RXJava-and-Retrofit-Users-Generated-Example-";
}
