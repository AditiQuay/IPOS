package quay.com.ipos.listeners;

/**
 * Created by niraj.kumar on 4/17/2018.
 */

public interface MyListenerProduct {
    void onUpdateCart(int position);

}
