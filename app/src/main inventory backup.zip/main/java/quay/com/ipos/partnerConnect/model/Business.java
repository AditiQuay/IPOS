package quay.com.ipos.partnerConnect.model;

import java.util.List;

public class Business {


    public List<KeyBusinessInfo> keyBusinessInfo;



}
