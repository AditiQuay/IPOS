package quay.com.ipos.inventory.modal;

/**
 * Created by niraj.kumar on 6/20/2018.
 */

public class GrnAttachment {
    private String grnAttachmentName;
    private String grnAttachmentUrl;
    private String grnAttachmentType;

    public String getGrnAttachmentName() {
        return grnAttachmentName;
    }

    public void setGrnAttachmentName(String grnAttachmentName) {
        this.grnAttachmentName = grnAttachmentName;
    }

    public String getGrnAttachmentUrl() {
        return grnAttachmentUrl;
    }

    public void setGrnAttachmentUrl(String grnAttachmentUrl) {
        this.grnAttachmentUrl = grnAttachmentUrl;
    }

    public String getGrnAttachmentType() {
        return grnAttachmentType;
    }

    public void setGrnAttachmentType(String grnAttachmentType) {
        this.grnAttachmentType = grnAttachmentType;
    }
}
