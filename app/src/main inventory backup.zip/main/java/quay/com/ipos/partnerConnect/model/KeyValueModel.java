package quay.com.ipos.partnerConnect.model;

public class KeyValueModel {
    public String key;
    public String value;

    public KeyValueModel(String key, String value) {
        this.key = key;
        this.value = value;
    }
}
