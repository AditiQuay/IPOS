package quay.com.ipos.ddrsales.model;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class POSummaryData {
    public String title;
    public int id;
    public int count;
    @SerializedName("model")
    public List<OrderModel> modelList;
}
