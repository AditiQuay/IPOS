package quay.com.ipos.data.local.entity;

import android.arch.persistence.room.Entity;
import android.support.annotation.NonNull;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

@Entity(tableName = "most_used", primaryKeys = "funName")
public class MostUsed {
    @Expose
    @NonNull
    @SerializedName("funName")
    public String funName;

    @Expose
    @SerializedName("count")
    public int count;



}
