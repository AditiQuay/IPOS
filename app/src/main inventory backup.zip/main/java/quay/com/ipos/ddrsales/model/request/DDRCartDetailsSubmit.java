package quay.com.ipos.ddrsales.model.request;

import java.util.List;

public class DDRCartDetailsSubmit {
    public String materialCode;
    public String materialName;
    public double materialValue;
    public int materialQty;
    public double materialUnitValue;
    public double materialCGSTRate;
    public double materialCGSTValue;
    public double materialSGSTRate;
    public double materialSGSTValue;
    public double materialIGSTRate;
    public double materialIGSTValue;
    public Boolean isFreeItem;
    public List<DDRScheme> dDRScheme = null;
    public List<DdrBatchDetail> ddrBatchDetail = null;
    public double discountValue;
    public int isBatch;
}

