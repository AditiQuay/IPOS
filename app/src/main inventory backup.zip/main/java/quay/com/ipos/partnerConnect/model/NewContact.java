package quay.com.ipos.partnerConnect.model;

public class NewContact {
    public int ID;
    public String RoleID;
    public String Role;
    public String Name;
    public String PrimaryMobile;
    public String SecondaryMobile;
    public String Email;

           /* "RoleID": "3",
            "Role": "User",
            "Name": "Ram Verma",
            "PrimaryMobile": "9717409994",
            "SecondaryMobile": "9617409994",
            "Email": "ram@kgm.com"*/

        /*   1 SuperAdmin NULL
2 Admin NULL
3 User NULL
4 Approver NULL
5 Management NULL*/
}
