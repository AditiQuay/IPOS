package quay.com.ipos.partnerConnect.model;

import java.util.List;

public class KeyBusinessContactInfo {
    public String keyEmpName;

    public String keyDesignation;

    public String keyMobile;

    public String keyMobile2;

    public String keyEmail;

    public String keyEmpNote;

    public List<NewContact> NewContact;


}
