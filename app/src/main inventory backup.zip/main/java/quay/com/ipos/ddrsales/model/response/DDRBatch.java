package quay.com.ipos.ddrsales.model.response;

public class DDRBatch {

    public String number;
    public String actionTitle="NA";
    public int actionID=0;
    public int qty;
    public DDRBatch(int batchQty, String batchNumber) {
        this.qty = batchQty;
        this.number = batchNumber;
    }
}
