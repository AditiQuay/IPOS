package quay.com.ipos.listeners;

/**
 * Created by niraj.kumar on 6/26/2018.
 */

public interface BatchTabButtonClick {
    void onTabClick(int position);
}
