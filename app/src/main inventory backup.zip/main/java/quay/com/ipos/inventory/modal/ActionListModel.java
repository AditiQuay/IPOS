package quay.com.ipos.inventory.modal;

import java.io.Serializable;

/**
 * Created by niraj.kumar on 6/23/2018.
 */

public class ActionListModel implements Serializable {
    public int actionID;
    public String actionTitle;
}
