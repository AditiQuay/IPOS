package quay.com.ipos.listeners;

/**
 * Created by niraj.kumar on 7/1/2018.
 */

public interface DataUpdateListener {
    void onUpdateData(int position,int inQty,int apQty,int balanceQty);
}
