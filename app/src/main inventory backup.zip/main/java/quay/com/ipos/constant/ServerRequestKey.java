package quay.com.ipos.constant;

/**
 * Created by niraj.kumar on 5/4/2018.
 */

public class ServerRequestKey {
    public static final String KEY_FCMTOKEN = "fcmToken";
}
