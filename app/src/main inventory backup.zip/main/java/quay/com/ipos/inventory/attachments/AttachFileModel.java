package quay.com.ipos.inventory.attachments;

import android.net.Uri;

/**
 * Created by deepak.kumar1 on 18-04-2018.
 */

public class AttachFileModel {
    public String fileName;
    public String fileUrl;
    public String mimeType;
    public Uri uri;

}
