package quay.com.ipos.listeners;

/**
 * Created by niraj.kumar on 6/22/2018.
 */

public interface OthersTabListner {
    void otherTabListner(int position);
}
