package quay.com.ipos.ddrsales.model.request;

public class DDRScheme {
    public int ruleID;
    public double discountValue;
    public double discountPerc;
    public String schemeID;
}
