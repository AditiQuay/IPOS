package quay.com.ipos.compliance.viewModel;

/**
 * Created by deepak.kumar1 on 05-04-2018.
 */

public interface ComplianceViewFilterSelectionListner {
    void onViewAllSelected();

    void onDoneSelected();

    void onImmediateSelected();

    void onUpcomingSelected();

    void onPendingSelected();
}
