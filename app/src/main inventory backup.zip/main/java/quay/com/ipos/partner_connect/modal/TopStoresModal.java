package quay.com.ipos.partner_connect.modal;

/**
 * Created by ankush.bansal on 17-04-2018.
 */

public class TopStoresModal {

    private String title;
    private String value;
    private String lessthan;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getLessthan() {
        return lessthan;
    }

    public void setLessthan(String lessthan) {
        this.lessthan = lessthan;
    }
}
