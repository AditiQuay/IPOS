package quay.com.ipos.data.remote.model;

public class APIError {

    private int statusCode;
    private String message;

    public APIError() {

        message = "Error Default";
    }

    public int status() {
        return statusCode;
    }

    public String message() {
        return message;
    }
}
