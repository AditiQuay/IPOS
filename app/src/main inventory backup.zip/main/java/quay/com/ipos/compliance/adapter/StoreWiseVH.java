package quay.com.ipos.compliance.adapter;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

import quay.com.ipos.R;


/**
 * Created by deepak.kumar1 on 19-03-2018.
 */

public class StoreWiseVH extends RecyclerView.ViewHolder {
    public TextView mCTCompliant;
    public TextView iposBlockTxt1;
    public TextView mCTNonCompliant;
    public TextView mCTImmediateAttention;
    public TextView mCTUpcomingEvents;

    public StoreWiseVH(View view) {
        super(view);
        iposBlockTxt1 = view.findViewById(R.id.ipos_block_txt1);
        mCTCompliant = view.findViewById(R.id.mCT_Compliant);
        mCTNonCompliant = view.findViewById(R.id.mCT_NonCompliant);
        mCTImmediateAttention = view.findViewById(R.id.mCT_ImmediateAttention);
        mCTUpcomingEvents = view.findViewById(R.id.mCT_UpcomingEvents);
    }
 
}
