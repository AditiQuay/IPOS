package quay.com.ipos.listeners;

/**
 * Created by niraj.kumar on 6/23/2018.
 */

public interface ActionListClick {
    void actionListClicked(int position);

}
