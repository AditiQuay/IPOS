package quay.com.ipos.partnerConnect.partnerConnectModel;

/**
 * Created by niraj.kumar on 6/7/2018.
 */

public class ContactModel {
    private String contactPosition;
    private String contactPerson;
    private String contactMobileNumber;
    private String contactMobileSecondaryMobile;
    private String contactEmail;
    private String contactNote;

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    private String role;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    private String name;

    public String getPrimaryMobile() {
        return primaryMobile;
    }

    public void setPrimaryMobile(String primaryMobile) {
        this.primaryMobile = primaryMobile;
    }

    public String getSecondaryMobile() {
        return secondaryMobile;
    }

    public void setSecondaryMobile(String secondaryMobile) {
        this.secondaryMobile = secondaryMobile;
    }

    private String primaryMobile;
    private String secondaryMobile;
}
