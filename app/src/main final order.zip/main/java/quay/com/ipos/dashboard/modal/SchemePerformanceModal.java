package quay.com.ipos.dashboard.modal;

/**
 * Created by ankush.bansal on 30-05-2018.
 */

public class SchemePerformanceModal {

    private String name;
    private String sales;
    private String target;
    private String achievement;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSales() {
        return sales;
    }

    public void setSales(String sales) {
        this.sales = sales;
    }

    public String getTarget() {
        return target;
    }

    public void setTarget(String target) {
        this.target = target;
    }

    public String getAchievement() {
        return achievement;
    }

    public void setAchievement(String achievement) {
        this.achievement = achievement;
    }
}
