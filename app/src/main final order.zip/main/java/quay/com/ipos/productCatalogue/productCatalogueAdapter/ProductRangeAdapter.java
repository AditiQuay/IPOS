package quay.com.ipos.productCatalogue.productCatalogueAdapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.view.ViewGroup;

/**
 * Created by niraj.kumar on 5/23/2018.
 */

public class ProductRangeAdapter extends RecyclerView.Adapter<ProductRangeAdapter.MyViewHolder> {
    private Context mContext;


    public ProductRangeAdapter(Context mContext){
        this.mContext = mContext;
    }
    @Override
    public ProductRangeAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return null;
    }

    @Override
    public void onBindViewHolder(ProductRangeAdapter.MyViewHolder holder, int position) {

    }

    @Override
    public int getItemCount() {
        return 0;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public MyViewHolder(View itemView) {
            super(itemView);
        }
    }
}
