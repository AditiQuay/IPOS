package quay.com.ipos.productCatalogue.productModal;

import java.io.Serializable;

/**
 * Created by niraj.kumar on 4/17/2018.
 */

public class ProductCatalogueModal implements Serializable{
    public String productName;
    public int productIcon;

    public ProductCatalogueModal(){

    }
}
