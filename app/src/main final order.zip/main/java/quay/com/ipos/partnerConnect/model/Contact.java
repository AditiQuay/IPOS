package quay.com.ipos.partnerConnect.model;

import java.util.List;

public class Contact {


    public KeyBusinessContactInfo KeyBusinessContactInfo;
 }
