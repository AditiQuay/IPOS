package quay.com.ipos.listeners;

/**
 * Created by niraj.kumar on 6/10/2018.
 */

public interface YourFragmentInterface {
    void fragmentBecameVisible();
}
