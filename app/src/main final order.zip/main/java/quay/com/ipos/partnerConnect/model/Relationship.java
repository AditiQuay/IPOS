package quay.com.ipos.partnerConnect.model;

import java.util.List;

public class Relationship {
    public String pssEntityName;
    public List<PssLOBS> pssLOBS;
    public List<PssPrincipleBankpaymentTo> pssPrincipleBankpaymentTo;
    public List<PssPrincipleContact> pssPrincipleContact;
}
