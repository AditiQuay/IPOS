package quay.com.ipos.productCatalogue.productModal;

import java.util.ArrayList;

/**
 * Created by niraj.kumar on 4/25/2018.
 */

public class ProductSectionModal {
    private String headerTitle;
    private String companyName;

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getStoreID() {
        return storeID;
    }

    public void setStoreID(String storeID) {
        this.storeID = storeID;
    }

    private String productId;
    private String storeID;
    public String getSectionProduct() {
        return sectionProduct;
    }

    public void setSectionProduct(String sectionProduct) {
        this.sectionProduct = sectionProduct;
    }

    private String sectionProduct;

    public ArrayList<ProductItemModal> getProductItemModals() {
        return productItemModals;
    }

    public void setProductItemModals(ArrayList<ProductItemModal> productItemModals) {
        this.productItemModals = productItemModals;
    }

    private ArrayList<ProductItemModal> productItemModals;

    public ProductSectionModal() {

    }

    public ProductSectionModal(String headerTitle, ArrayList<ProductItemModal> productItemModals) {
        this.headerTitle = headerTitle;
        this.productItemModals = productItemModals;
    }

    public String getHeaderTitle() {
        return headerTitle;
    }

    public void setHeaderTitle(String headerTitle) {
        this.headerTitle = headerTitle;
    }


    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }
}
