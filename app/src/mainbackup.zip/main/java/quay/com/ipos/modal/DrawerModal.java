package quay.com.ipos.modal;

/**
 * Created by niraj.kumar on 4/17/2018.
 */

public class DrawerModal {
    public int icon;
    public String name;

    // Constructor.
    public DrawerModal(int icon, String name) {

        this.icon = icon;
        this.name = name;
    }
}
