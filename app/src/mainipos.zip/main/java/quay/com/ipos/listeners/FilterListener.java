package quay.com.ipos.listeners;

/**
 * Created by ankush.bansal on 27-04-2018.
 */

public interface FilterListener
{
    public void onUpdateTitle(String title);
}