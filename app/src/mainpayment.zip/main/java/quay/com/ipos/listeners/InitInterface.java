package quay.com.ipos.listeners;


// Initialize Interface
public interface InitInterface {

    void findViewById();

    void applyInitValues();

    void applyTypeFace();

    boolean applyLocalValidation();


}
