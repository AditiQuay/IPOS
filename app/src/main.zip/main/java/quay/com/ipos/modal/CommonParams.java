package quay.com.ipos.modal;

/**
 * Created by aditi.bhuranda on 15-05-2018.
 */

public class CommonParams {
    private String storeId;
    private String searchParam;
    private String barCodeNumber;

    public String getStoreId() {
        return storeId;
    }

    public void setStoreId(String storeId) {
        this.storeId = storeId;
    }

    public String getSearchParam() {
        return searchParam;
    }

    public void setSearchParam(String searchParam) {
        this.searchParam = searchParam;
    }

    public String getBarCodeNumber() {
        return barCodeNumber;
    }

    public void setBarCodeNumber(String barCodeNumber) {
        this.barCodeNumber = barCodeNumber;
    }
}
