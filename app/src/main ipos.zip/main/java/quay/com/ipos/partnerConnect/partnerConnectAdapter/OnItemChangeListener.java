package quay.com.ipos.partnerConnect.partnerConnectAdapter;

public interface OnItemChangeListener {
    void onItemChanged(int position);
}
