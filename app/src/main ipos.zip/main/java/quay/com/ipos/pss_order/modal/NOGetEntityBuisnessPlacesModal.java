package quay.com.ipos.pss_order.modal;

/**
 * Created by ankush.bansal on 04-06-2018.
 */

public class NOGetEntityBuisnessPlacesModal {


    /**
     * entityCode : 1
     * entityType : distributer
     * entityRole : manager
     */

    private String entityCode;
    private String entityType;
    private String entityRole;

    public String getEntityCode() {
        return entityCode;
    }

    public void setEntityCode(String entityCode) {
        this.entityCode = entityCode;
    }

    public String getEntityType() {
        return entityType;
    }

    public void setEntityType(String entityType) {
        this.entityType = entityType;
    }

    public String getEntityRole() {
        return entityRole;
    }

    public void setEntityRole(String entityRole) {
        this.entityRole = entityRole;
    }
}
