package quay.com.ipos.productCatalogue.productModal;

import java.util.List;

/**
 * Created by niraj.kumar on 5/26/2018.
 */

public class CatalogueServerModel {


    /**
     * count : 2
     * data : [{"productCode":"Billo","sProductName":"Billo 1 kg","sProductUrl":"https://www.khedutstore.com/p3y9_inv/admin/img/product/orignal/276108.jpg","sProductFeature":"for insectiside","sProductPrice":"150.00 - 450.00","sDataSheet":"http://www.orimi.com/pdf-test.pdf","sPoints":0,"isOnOffer":true,"isCalculator":true,"isDataSheet":true},{"productCode":"Nidan","sProductName":"Nidan","sProductUrl":"https://www.khedutstore.com/p3y9_inv/admin/img/product/orignal/276108.jpg","sProductFeature":"for Pestiside","sProductPrice":"750.00 - 750.00","sDataSheet":"http://www.orimi.com/pdf-test.pdf","sPoints":0,"isOnOffer":true,"isCalculator":true,"isDataSheet":true}]
     */

    private int count;
    private List<DataBean> data;

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public List<DataBean> getData() {
        return data;
    }

    public void setData(List<DataBean> data) {
        this.data = data;
    }

    public static class DataBean {
        /**
         * productCode : Billo
         * sProductName : Billo 1 kg
         * sProductUrl : https://www.khedutstore.com/p3y9_inv/admin/img/product/orignal/276108.jpg
         * sProductFeature : for insectiside
         * sProductPrice : 150.00 - 450.00
         * sDataSheet : http://www.orimi.com/pdf-test.pdf
         * sPoints : 0.0
         * isOnOffer : true
         * isCalculator : true
         * isDataSheet : true
         */

        private String productCode;
        private String sProductName;
        private String sProductUrl;
        private String sProductFeature;
        private String sProductPrice;
        private String sDataSheet;
        private double sPoints;
        private boolean isOnOffer;
        private boolean isCalculator;
        private boolean isDataSheet;

        public String getProductCode() {
            return productCode;
        }

        public void setProductCode(String productCode) {
            this.productCode = productCode;
        }

        public String getSProductName() {
            return sProductName;
        }

        public void setSProductName(String sProductName) {
            this.sProductName = sProductName;
        }

        public String getSProductUrl() {
            return sProductUrl;
        }

        public void setSProductUrl(String sProductUrl) {
            this.sProductUrl = sProductUrl;
        }

        public String getSProductFeature() {
            return sProductFeature;
        }

        public void setSProductFeature(String sProductFeature) {
            this.sProductFeature = sProductFeature;
        }

        public String getSProductPrice() {
            return sProductPrice;
        }

        public void setSProductPrice(String sProductPrice) {
            this.sProductPrice = sProductPrice;
        }

        public String getSDataSheet() {
            return sDataSheet;
        }

        public void setSDataSheet(String sDataSheet) {
            this.sDataSheet = sDataSheet;
        }

        public double getSPoints() {
            return sPoints;
        }

        public void setSPoints(double sPoints) {
            this.sPoints = sPoints;
        }

        public boolean isIsOnOffer() {
            return isOnOffer;
        }

        public void setIsOnOffer(boolean isOnOffer) {
            this.isOnOffer = isOnOffer;
        }

        public boolean isIsCalculator() {
            return isCalculator;
        }

        public void setIsCalculator(boolean isCalculator) {
            this.isCalculator = isCalculator;
        }

        public boolean isIsDataSheet() {
            return isDataSheet;
        }

        public void setIsDataSheet(boolean isDataSheet) {
            this.isDataSheet = isDataSheet;
        }
    }
}
