package quay.com.ipos.partnerConnect.model;

public class PssPrincipleBankpaymentTo {
    public String EntityPaytoName;
    public String principleAccountNo;
    public String principleBankName;
    public String principleBankBranchName;
    public String principleBankIFSCode;





               /*     "EntityPaytoName": "Mccoy",
                            "principleAccountNo": "SBI1234567890",
                            "principleBankName": "Statet Bank Of India",
                            "principleBankBranchName": "Gurgaon",
                            "principleBankIFSCode": "SBI0001265"
*/
}
