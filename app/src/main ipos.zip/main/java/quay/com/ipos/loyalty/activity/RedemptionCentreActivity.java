package quay.com.ipos.loyalty.activity;

import android.os.Bundle;
import android.support.annotation.Nullable;

import quay.com.ipos.R;
import quay.com.ipos.base.BaseActivity;

/**
 * Created by aditi.bhuranda on 16-06-2018.
 */

public class RedemptionCentreActivity extends BaseActivity {
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.act_redemption_centre_loyalty);
    }
}
