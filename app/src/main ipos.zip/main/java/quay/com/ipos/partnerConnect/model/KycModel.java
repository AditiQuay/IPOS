package quay.com.ipos.partnerConnect.model;

/**
 * Created by niraj.kumar on 6/11/2018.
 */

public class KycModel {
    public int documentId;
    public String documentName;
    public String approvalStatus;
    public String productUrl;
    public String message;

}
