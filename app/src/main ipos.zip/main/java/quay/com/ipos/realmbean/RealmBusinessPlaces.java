package quay.com.ipos.realmbean;

import io.realm.RealmObject;
import io.realm.annotations.PrimaryKey;

/**
 * Created by ankush.bansal on 11-06-2018.
 */

public class RealmBusinessPlaces extends RealmObject {

    @PrimaryKey
    private int buisnessPlaceId;
    private String buisnessPlaceName;
    private String buisnessLocationStateCode;
    private String header;
    private boolean isSelected;

    public int getBuisnessPlaceId() {
        return buisnessPlaceId;
    }

    public void setBuisnessPlaceId(int buisnessPlaceId) {
        this.buisnessPlaceId = buisnessPlaceId;
    }

    public String getBuisnessPlaceName() {
        return buisnessPlaceName;
    }

    public void setBuisnessPlaceName(String buisnessPlaceName) {
        this.buisnessPlaceName = buisnessPlaceName;
    }

    public String getBuisnessLocationStateCode() {
        return buisnessLocationStateCode;
    }

    public void setBuisnessLocationStateCode(String buisnessLocationStateCode) {
        this.buisnessLocationStateCode = buisnessLocationStateCode;
    }

    public String getHeader() {
        return header;
    }

    public void setHeader(String header) {
        this.header = header;
    }

    public boolean isSelected() {
        return isSelected;
    }

    public void setSelected(boolean selected) {
        isSelected = selected;
    }
}
