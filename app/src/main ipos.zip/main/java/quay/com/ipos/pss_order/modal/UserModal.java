package quay.com.ipos.pss_order.modal;

/**
 * Created by ankush.bansal on 25-04-2018.
 */


public class UserModal {

    private   String id;
    private String userName;
    private String userStatus;
    private String userDateStatus;
    private String level;
    private String flag;
    private String comment;
    private String date;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserStatus() {
        return userStatus;
    }

    public void setUserStatus(String userStatus) {
        this.userStatus = userStatus;
    }

    public String getUserDateStatus() {
        return userDateStatus;
    }

    public void setUserDateStatus(String userDateStatus) {
        this.userDateStatus = userDateStatus;
    }

    public String getLevel() {
        return level;
    }

    public void setLevel(String level) {
        this.level = level;
    }

    public String getFlag() {
        return flag;
    }

    public void setFlag(String flag) {
        this.flag = flag;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}


