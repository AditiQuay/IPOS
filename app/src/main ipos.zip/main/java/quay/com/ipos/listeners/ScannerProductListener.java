package quay.com.ipos.listeners;

import quay.com.ipos.modal.ProductList;

/**
 * Created by aditi.bhuranda on 02-05-2018.
 */

public interface ScannerProductListener {

    public void setProductOnListener(String mDatum);
}
