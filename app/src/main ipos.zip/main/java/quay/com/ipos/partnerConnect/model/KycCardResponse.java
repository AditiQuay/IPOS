package quay.com.ipos.partnerConnect.model;

/**
 * Created by niraj.kumar on 6/15/2018.
 */

public class KycCardResponse {
    public int statusCode;
    public String message;
    public KycCardModel response;

}
