package quay.com.ipos.data.remote;

public class URLStorage {

    public static final String BASE_URL = "http://13.127.101.233:8087/";
    //@Query("sort") String sort  "api/PSSConnects/getPssConnectDetail?strEntityId=1";
    public static final String PARTNER_CONNECT_API = "api/PSSConnects/getPssConnectDetail";
    public static final String PARTNER_CONNECT_UPDATE_API = "api/PSSConnects/UpdatePssdetail";
}
