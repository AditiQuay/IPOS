package quay.com.ipos.realmbean;

import java.io.Serializable;

import io.realm.RealmObject;
import io.realm.annotations.PrimaryKey;

/**
 * Created by niraj.kumar on 4/30/2018.
 */

public class RealmCustomerInfoModal extends RealmObject {
    @PrimaryKey
    public int customerID;
    public String customer_name;
    public String customer_points;
    public String customer_phone;
    public String customer_email;
    public String customer_bday;
    public String customer_address;
    public String last_billing;
    public String recent_orders;
//
//    private int i1;
//    private int i2;
//    private int i3;
//    private int i4;
//    private int i5;
//    private int i6;
//    private int i7;
//    private int i8;
//    private int i9;
//    private int i10;
//    private int i11;
//    private int i12;
//    private int i13;
//    private int i14;
//    private int i15;
//    private int i16;
//    private int i17;
//    private int i18;
//    private int i19;
//    private int i20;
//    private int i21;
//    private int i22;
//    private int i23;
//    private int i24;
//    private int i25;
//    private int i26;
//    private int i27;
//    private int i28;
//    private int i29;
//    private int i30;
//    private int i31;
//    private int i32;
//    private int i33;
//    private int i34;
//    private int i35;
//    private int i36;
//    private int i37;
//    private int i38;
//    private int i39;
//    private int i40;
//    private int i41;
//    private int i42;
//    private int i43;
//    private int i44;
//    private int i45;
//    private int i46;
//    private int i47;
//    private int i48;
//    private int i49;
//    private int i50;
//










    public int getCustomerID() {
        return customerID;
    }

    public void setCustomerID(int customerID) {
        this.customerID = customerID;
    }

    public String getCustomer_name() {
        return customer_name;
    }

    public void setCustomer_name(String customer_name) {
        this.customer_name = customer_name;
    }

    public String getCustomer_points() {
        return customer_points;
    }

    public void setCustomer_points(String customer_points) {
        this.customer_points = customer_points;
    }

    public String getCustomer_phone() {
        return customer_phone;
    }

    public void setCustomer_phone(String customer_phone) {
        this.customer_phone = customer_phone;
    }

    public String getCustomer_email() {
        return customer_email;
    }

    public void setCustomer_email(String customer_email) {
        this.customer_email = customer_email;
    }

    public String getCustomer_bday() {
        return customer_bday;
    }

    public void setCustomer_bday(String customer_bday) {
        this.customer_bday = customer_bday;
    }

    public String getCustomer_address() {
        return customer_address;
    }

    public void setCustomer_address(String customer_address) {
        this.customer_address = customer_address;
    }

    public String getLast_billing() {
        return last_billing;
    }

    public void setLast_billing(String last_billing) {
        this.last_billing = last_billing;
    }

    public String getRecent_orders() {
        return recent_orders;
    }

    public void setRecent_orders(String recent_orders) {
        this.recent_orders = recent_orders;
    }

//    public int getI1() {
//        return i1;
//    }
//
//    public void setI1(int i1) {
//        this.i1 = i1;
//    }
//
//    public int getI2() {
//        return i2;
//    }
//
//    public void setI2(int i2) {
//        this.i2 = i2;
//    }
//
//    public int getI3() {
//        return i3;
//    }
//
//    public void setI3(int i3) {
//        this.i3 = i3;
//    }
//
//    public int getI4() {
//        return i4;
//    }
//
//    public void setI4(int i4) {
//        this.i4 = i4;
//    }
//
//    public int getI5() {
//        return i5;
//    }
//
//    public void setI5(int i5) {
//        this.i5 = i5;
//    }
//
//    public int getI6() {
//        return i6;
//    }
//
//    public void setI6(int i6) {
//        this.i6 = i6;
//    }
//
//    public int getI7() {
//        return i7;
//    }
//
//    public void setI7(int i7) {
//        this.i7 = i7;
//    }
//
//    public int getI8() {
//        return i8;
//    }
//
//    public void setI8(int i8) {
//        this.i8 = i8;
//    }
//
//    public int getI9() {
//        return i9;
//    }
//
//    public void setI9(int i9) {
//        this.i9 = i9;
//    }
//
//    public int getI10() {
//        return i10;
//    }
//
//    public void setI10(int i10) {
//        this.i10 = i10;
//    }
//
//    public int getI11() {
//        return i11;
//    }
//
//    public void setI11(int i11) {
//        this.i11 = i11;
//    }
//
//    public int getI12() {
//        return i12;
//    }
//
//    public void setI12(int i12) {
//        this.i12 = i12;
//    }
//
//    public int getI13() {
//        return i13;
//    }
//
//    public void setI13(int i13) {
//        this.i13 = i13;
//    }
//
//    public int getI14() {
//        return i14;
//    }
//
//    public void setI14(int i14) {
//        this.i14 = i14;
//    }
//
//    public int getI15() {
//        return i15;
//    }
//
//    public void setI15(int i15) {
//        this.i15 = i15;
//    }
//
//    public int getI16() {
//        return i16;
//    }
//
//    public void setI16(int i16) {
//        this.i16 = i16;
//    }
//
//    public int getI17() {
//        return i17;
//    }
//
//    public void setI17(int i17) {
//        this.i17 = i17;
//    }
//
//    public int getI18() {
//        return i18;
//    }
//
//    public void setI18(int i18) {
//        this.i18 = i18;
//    }
//
//    public int getI19() {
//        return i19;
//    }
//
//    public void setI19(int i19) {
//        this.i19 = i19;
//    }
//
//    public int getI20() {
//        return i20;
//    }
//
//    public void setI20(int i20) {
//        this.i20 = i20;
//    }
//
//    public int getI21() {
//        return i21;
//    }
//
//    public void setI21(int i21) {
//        this.i21 = i21;
//    }
//
//    public int getI22() {
//        return i22;
//    }
//
//    public void setI22(int i22) {
//        this.i22 = i22;
//    }
//
//    public int getI23() {
//        return i23;
//    }
//
//    public void setI23(int i23) {
//        this.i23 = i23;
//    }
//
//    public int getI24() {
//        return i24;
//    }
//
//    public void setI24(int i24) {
//        this.i24 = i24;
//    }
//
//    public int getI25() {
//        return i25;
//    }
//
//    public void setI25(int i25) {
//        this.i25 = i25;
//    }
//
//    public int getI26() {
//        return i26;
//    }
//
//    public void setI26(int i26) {
//        this.i26 = i26;
//    }
//
//    public int getI27() {
//        return i27;
//    }
//
//    public void setI27(int i27) {
//        this.i27 = i27;
//    }
//
//    public int getI28() {
//        return i28;
//    }
//
//    public void setI28(int i28) {
//        this.i28 = i28;
//    }
//
//    public int getI29() {
//        return i29;
//    }
//
//    public void setI29(int i29) {
//        this.i29 = i29;
//    }
//
//    public int getI30() {
//        return i30;
//    }
//
//    public void setI30(int i30) {
//        this.i30 = i30;
//    }
//
//    public int getI31() {
//        return i31;
//    }
//
//    public void setI31(int i31) {
//        this.i31 = i31;
//    }
//
//    public int getI32() {
//        return i32;
//    }
//
//    public void setI32(int i32) {
//        this.i32 = i32;
//    }
//
//    public int getI33() {
//        return i33;
//    }
//
//    public void setI33(int i33) {
//        this.i33 = i33;
//    }
//
//    public int getI34() {
//        return i34;
//    }
//
//    public void setI34(int i34) {
//        this.i34 = i34;
//    }
//
//    public int getI35() {
//        return i35;
//    }
//
//    public void setI35(int i35) {
//        this.i35 = i35;
//    }
//
//    public int getI36() {
//        return i36;
//    }
//
//    public void setI36(int i36) {
//        this.i36 = i36;
//    }
//
//    public int getI37() {
//        return i37;
//    }
//
//    public void setI37(int i37) {
//        this.i37 = i37;
//    }
//
//    public int getI38() {
//        return i38;
//    }
//
//    public void setI38(int i38) {
//        this.i38 = i38;
//    }
//
//    public int getI39() {
//        return i39;
//    }
//
//    public void setI39(int i39) {
//        this.i39 = i39;
//    }
//
//    public int getI40() {
//        return i40;
//    }
//
//    public void setI40(int i40) {
//        this.i40 = i40;
//    }
//
//    public int getI41() {
//        return i41;
//    }
//
//    public void setI41(int i41) {
//        this.i41 = i41;
//    }
//
//    public int getI42() {
//        return i42;
//    }
//
//    public void setI42(int i42) {
//        this.i42 = i42;
//    }
//
//    public int getI43() {
//        return i43;
//    }
//
//    public void setI43(int i43) {
//        this.i43 = i43;
//    }
//
//    public int getI44() {
//        return i44;
//    }
//
//    public void setI44(int i44) {
//        this.i44 = i44;
//    }
//
//    public int getI45() {
//        return i45;
//    }
//
//    public void setI45(int i45) {
//        this.i45 = i45;
//    }
//
//    public int getI46() {
//        return i46;
//    }
//
//    public void setI46(int i46) {
//        this.i46 = i46;
//    }
//
//    public int getI47() {
//        return i47;
//    }
//
//    public void setI47(int i47) {
//        this.i47 = i47;
//    }
//
//    public int getI48() {
//        return i48;
//    }
//
//    public void setI48(int i48) {
//        this.i48 = i48;
//    }
//
//    public int getI49() {
//        return i49;
//    }
//
//    public void setI49(int i49) {
//        this.i49 = i49;
//    }
//
//    public int getI50() {
//        return i50;
//    }
//
//    public void setI50(int i50) {
//        this.i50 = i50;
//    }
}
