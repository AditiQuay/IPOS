package quay.com.ipos.partnerConnect.model;

import java.util.List;

public class Relationship {
    public String pssEntityName;
    public List<PssPrincipleBankpaymentTo> pssPrincipleBankpaymentTo;
    public List<PssLOBS> pssLOBS;
    public List<PssPrincipleContact> pssPrincipleContact;
}
