package quay.com.ipos.modal;

/**
 * Created by ankush.bansal on 17-04-2018.
 */

public class RecentOrderModal {

    private String title;
    private String value;
    private String lessthan;
    private String discountValue;
    private String qty;


    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getLessthan() {
        return lessthan;
    }

    public void setLessthan(String lessthan) {
        this.lessthan = lessthan;
    }

    public String getDiscountValue() {
        return discountValue;
    }

    public void setDiscountValue(String discountValue) {
        this.discountValue = discountValue;
    }

    public String getQty() {
        return qty;
    }

    public void setQty(String qty) {
        this.qty = qty;
    }
}
