package quay.com.ipos.listeners;

import quay.com.ipos.pss_order.modal.DiscountModal;

/**
 * Created by ankush.bansal on 07-06-2018.
 */

public interface MyCheckedChangedListener {

    void onDiscount(DiscountModal discountModal, int position, boolean b, String productId, String productCode);
}
