package quay.com.ipos.partnerConnect.viewDialog;

import android.support.v4.app.DialogFragment;

/**
 * Created by niraj.kumar on 6/12/2018.
 */

public class ViewDialog extends DialogFragment {

}
