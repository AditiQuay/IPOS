package quay.com.ipos.listeners;

/**
 * Created by ankush.bansal on 26-02-2018.
 */


public interface PageChangeInterface {
    public void onDataPass(String data, int pos, String categoryId);
}
