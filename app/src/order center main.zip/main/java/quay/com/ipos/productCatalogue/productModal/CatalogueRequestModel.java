package quay.com.ipos.productCatalogue.productModal;

/**
 * Created by niraj.kumar on 6/11/2018.
 */

public class CatalogueRequestModel {
    public String companyName;
    public String productId;
    public String storeID;


    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getStoreID() {
        return storeID;
    }

    public void setStoreID(String storeID) {
        this.storeID = storeID;
    }
}
