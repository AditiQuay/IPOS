package quay.com.ipos.modal;

/**
 * Created by niraj.kumar on 4/17/2018.
 */

public class ProductCatalogueModal {
    public String productName;
    public int productIcon;

    public ProductCatalogueModal(){

    }
}
