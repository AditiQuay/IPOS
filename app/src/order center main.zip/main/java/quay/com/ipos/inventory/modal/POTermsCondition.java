package quay.com.ipos.inventory.modal;

/**
 * Created by ankush.bansal on 15-06-2018.
 */

public class POTermsCondition {

    public int pOTermsAndConditionSrNo;
    public String pOTermsAndConditionDetail;

    public int getpOTermsAndConditionSrNo() {
        return pOTermsAndConditionSrNo;
    }

    public void setpOTermsAndConditionSrNo(int pOTermsAndConditionSrNo) {
        this.pOTermsAndConditionSrNo = pOTermsAndConditionSrNo;
    }

    public String getpOTermsAndConditionDetail() {
        return pOTermsAndConditionDetail;
    }

    public void setpOTermsAndConditionDetail(String pOTermsAndConditionDetail) {
        this.pOTermsAndConditionDetail = pOTermsAndConditionDetail;
    }
}
