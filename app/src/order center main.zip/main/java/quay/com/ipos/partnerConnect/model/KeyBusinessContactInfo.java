package quay.com.ipos.partnerConnect.model;

import java.util.List;

public class KeyBusinessContactInfo {
    public String keyEmpName;

    public String keyDesignation;

    public String keyMobile;

    public String keyMobile2;

    public String keyEmail;

    public String keyEmpNote;

    public List<NewContact> NewContact;

     /*          "keyEmpName": "Alok Sharma",
                "keyDesignation": "Director",
                "keyMobile": "8880023456",
                "keyMobile2": "8880023457",
                "keyEmail": "alok@kgm.com",
                "keyEmpNote": "added contacts for my test",
                "NewContact": [*/
}
