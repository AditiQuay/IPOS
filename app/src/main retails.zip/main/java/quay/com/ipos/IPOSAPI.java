package quay.com.ipos;

/**
 * API Methods of IPOS
 */
public  class IPOSAPI {
    public static String CONTENT_TYPE = "Content-Type";
    public static String APPLICATION_JSON = "application/json";
  //  MediaType JSON = MediaType.parse("application/json; charset=utf-8");
  public static String WEB_SERVICE_BASE_URL = "http://13.127.101.233:3005/api/";
    public static String WEB_SERVICE_LOGIN = WEB_SERVICE_BASE_URL + "login";




}
