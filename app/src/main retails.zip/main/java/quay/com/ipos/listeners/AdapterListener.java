package quay.com.ipos.listeners;

/**
 * Created by aditi.bhuranda on 25-04-2018.
 */

public interface AdapterListener {
        void onRowClicked(int position);
        void onRowClicked(int position, int value);
}
