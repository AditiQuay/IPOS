package quay.com.ipos.modal;

/**
 * Created by niraj.kumar on 4/17/2018.
 */

public class CatalogueModal {
    public String sProductName;
    public String sProductFeature;
    public String sProductPrice;

    public CatalogueModal() {

    }

}
